<?php
require_once 'indexD.php';
class Departements {
    public $departmentID;
    public $departmentName;
    public $departmentHead;
    public $location;
    public $connect;

    function __construct($id, $name, $head, $location, $connect) {
        $this->departmentID = $id;
        $this->departmentName = $name;
        $this->departmentHead = $head;
        $this->location = $location;
        $this->connect = $connect;
    }

    function create_table() {
        $request = "CREATE TABLE IF NOT EXISTS `departements` (
                        `departmentID` int(11) PRIMARY KEY,
                        `departmentName` varchar(255),
                        `departmentHead` varchar(255),
                        `location` varchar(255)
                    )";
        $x = $this->connect->prepare($request);
        $e = $x->execute();
        if (!$e) {
            echo "Table departements not created!!<br>";
        } else {
            echo "Table departements bien créée !! ";
        }
    }
    function insert() {
        $request = "INSERT INTO `departements` (`DepartmentID`, `DepartmentName`, `DepartmentHead`, `Location`) values  
                    ('" . $this->departmentID . "','" . $this->departmentName . "','" . $this->departmentHead . "','" . $this->location . "')";
        $x = $this->connect->prepare($request);
        $e = $x->execute();
        if (!$e) {
            echo "Les données du département n'ont pas pu être insérées !! <br>";
        } else {
            echo "Les données du département ont été insérées avec succès !! <br>";
        }
    }
}
echo "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>";
$departement = new Departements("1", "Computer Science", "Dr. Smith", "Building A", $db->connexion);
$departement->create_table();
$departement->insert();
$departement = new Departements("2", "GTR", "Belkhire", "ST", $db->connexion);
$departement->insert();
?>