<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background: linear-gradient(45deg, #2193b0, #6dd5ed);
            color: #000; /* Changement de la couleur du texte à noir */
            font-family: Arial, sans-serif;
            animation: gradientAnimation 10s infinite alternate;
        }

        header {
            text-align: center;
            margin-bottom: 20px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: center;
        }

        nav li {
            margin: 0 10px;
            font-weight: bold; /* Met en gras les éléments de la barre de navigation */
        }

        nav a {
            text-decoration: none;
            color: #000; /* Changement de la couleur du texte à noir */
        }

        main {
            text-align: center;
        }

        /* Animation du fond */
        @keyframes gradientAnimation {
            0% {
                background-position: 0% 50%;
            }
            100% {
                background-position: 100% 50%;
            }
        }
        
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votre Application Universitaire</title>

</head>
<body>
    <header>
        <h1>Votre Application Universitaire</h1>
        
        <nav>
            <ul>
                <li><a href="./Database.php">Accueil</a></li>
                <li><a href="./Etudiants.php">Gérer les étudiants</a></li>
                <li><a href="./Cours.php">Gérer les cours</a></li>
                <li><a href="./Professeurs.php">Gérer les professeurs</a></li>
                <li><a href="./Inscriptions.php">Gérer les inscriptions</a></li>
                <li><a href="./Departements.php">Gérer les départements</a></li>
            </ul>
        </nav>
    </header>

    <main>
    <?php



if (isset($_GET['page'])) {
    $page = $_GET['page'];
    $pagePath = "$page.php";
    if (file_exists($pagePath)) {
        include($pagePath);
    } else {
        echo "La page demandée n'existe pas.";
    }
} else {
    echo "Bienvenue sur la page d'accueil !<br>";
}
?>
    </main>

    <footer>
        <!-- Ajoutez le contenu du pied de page si nécessaire -->
    </footer>
</body>
</html>
